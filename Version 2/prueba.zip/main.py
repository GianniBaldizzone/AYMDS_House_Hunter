from iniciosesion import InicioSesion
from Menu import Menu


menu_inicio_sesion = InicioSesion()

menu_inicio_sesion.mostrar_inicio_sesion()

