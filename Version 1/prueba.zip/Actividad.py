class Actividad:
    def __init__(self, id: int, nombre: str, cantidad: int):
        self.id = id
        self.nombre = nombre
        self.cantidad = cantidad