class Huesped:
    def __init__(self, id: int, nombre: str, apellido: str, nroDePasaporte: str, dni: int, nacionalidad: str, grupoSanguineo: str, seguroDeVida: int):
        self.id = id
        self.nombre = nombre
        self.apellido = apellido
        self.nroDePasaporte = nroDePasaporte
        self.dni = dni
        self.nacionalidad = nacionalidad
        self.grupoSanguineo = grupoSanguineo
        self.seguroDeVida = seguroDeVida   